const express = require('express');
const mongoose=require("mongoose")
const Book = require('./Book.js')
const app = express();

app.use(express.json())


 
  



mongoose.connect('mongodb://localhost:27017/JS3',()=>{
    console.log("Connected to database")
});


app.post('/book', async (req,res)=>
{
   

   console.log(req.body)
const book=req.body

    const newBook = new Book({
        ISBN: book.ISBN,
        name: book.name,
        price: book.price,
        isInStock: book.isInStock,
        edition: book.edition,
        printDate: book.printDate,
      });

    try{
        await newBook.save()
    }catch(err){
        console.log(err)
    }

    res.json(req.body)
})

app.get('/book', async (req,res)=>{
    try{
        const data = await Book.find()
        res.send(data)
    }catch(err){
        console.log(err)
    }
})

app.get('/book/:id', async (req,res)=>{

    console.log(req.params.id)

    try{
        const data = await Book.find({"ISBN":req.params.id})
        console.log("By id : ",data)
        res.send(data)
    }catch(err){
       res.send("Error occcured")
    }
})

app.put('/book/:id',async (req,res)=>{
    const {id}=req.params
    const book=req.body
    const newBook = {
        name: book.name,
        price: book.price,
        isInStock: book.isInStock,
        edition: book.edition,
        printDate: book.printDate,
      };

      try {
        updatedBook = await Book.findOneAndUpdate({ ISBN: id }, newBook, { new: true });
      } catch (err) {
        console.log(err);
        return res.send('Error occurred while updating the book');
      }
    
      res.json({ book: updatedBook });



})


app.delete('/book/:id', async (req,res)=>{

    const {id}=req.params
    

    try {
        await Book.findOneAndDelete({ ISBN: id });
      } catch (err) {
        console.log(err);
        return res.send('Error occurred while deleting the book');
      }
    
      res.send("Book data deleted");


})


app.listen(3001,()=>{
    console.log("Server started")
})